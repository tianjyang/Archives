import React from 'react';
import ReactDOM from 'react-dom';
import Store from './store/store';
import Root from './components/root';

// class Root extends React.Component {
//   render(){
//     return (
//     <Provider store={this.props.store}>
//       <Search/>
//     </Provider>
//   );}
// }

const RenderRoot = () => {
  console.log("redering some root");
  let root = document.getElementById("root");
  let store = Store();
  window.store = store;
  ReactDOM.render(<Root store={store}/>,root);
};

window.addEventListener("DOMContentLoaded",RenderRoot);
