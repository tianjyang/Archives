import {ObjToArray} from '../reducers/selector';

class MarkerManager {
  constructor(map){
    this.map = map;
    this.markers = [];
  }

  updateMarkers(benches) {
    let benchArray = ObjToArray(benches);
    this._replaceAllBenches(benchArray);
  }

  _replaceAllBenches(benches){
    this.markers.forEach((el)=>{
      el.setMap(null);
    });
    this.markers = [];
    benches.forEach((el)=>{
      this._createMarkerFromBench(el);
    });
  }

  _createMarkerFromBench(bench) {
    let pos = {
      lat: bench.lat,
      lng: bench.long
    };

    let marker = new google.maps.Marker({
      position: pos,
      title: JSON.stringify(bench.id)
    });

    marker.setMap(this.map);
    this.markers.push(marker);
  }
}

export default MarkerManager;
