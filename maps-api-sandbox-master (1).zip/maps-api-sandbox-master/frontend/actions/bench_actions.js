export const BenchConstants = {
    RECEIVE_BENCHES: "RECEIVE_BENCHES",
    REQUEST_BENCHES: "REQUEST_BENCHES",
    CREATE_BENCH: "CREATE_BENCH"
  };


export const requestBenches = () => ({
  type: BenchConstants.REQUEST_BENCHES
});

export const receiveBenches = (benches={}) => ({
  type: BenchConstants.RECEIVE_BENCHES,
  benches
});

export const createBench = (bench={}) => ({
  type: BenchConstants.CREATE_BENCH,
  bench
});

window.requestBenches = requestBenches;
window.receiveBenches = receiveBenches;
