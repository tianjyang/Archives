import { BenchConstants } from '../actions/bench_actions';
import { merge } from 'lodash';

const BenchesReducer = (state = {}, action) => {
  debugger
  switch (action.type) {
    case BenchConstants.RECEIVE_BENCHES:
      return merge({},state,action.benches);
    default:
      return state;
  }
};

export default BenchesReducer;
