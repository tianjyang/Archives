const ObjToArray = (inputObject) => {
  let indices = Object.keys(inputObject);
  return indices.map((element)=>(inputObject[element]));
};

export {ObjToArray};
