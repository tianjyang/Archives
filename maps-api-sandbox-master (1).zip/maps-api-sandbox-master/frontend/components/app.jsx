import React from 'react';
const App = ({ children }) => {

  return(
    <div>
      <h1>Bench BnB</h1>
      {children}
    </div>
  );
};

export default App;
