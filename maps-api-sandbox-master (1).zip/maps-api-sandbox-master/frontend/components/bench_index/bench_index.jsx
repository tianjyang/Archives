import React from 'react';
import { ObjToArray } from '../../reducers/selector';

class BenchIndex extends React.Component{
  componentDidMount(){
    this.props.requestBenches();
  }

  render() {
    let benchesArray = ObjToArray(this.props.benches);
    console.log(benchesArray);
    return(
      <div>
        <ul>
          {benchesArray.map((element) => {
            return(<li key={element.id}>{element.description}
              {element.lat} {element.long}</li>);
          })}
        </ul>
      </div>
    );
  }

}

export default BenchIndex;
