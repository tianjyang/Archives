import React from "react";
import { withRouter } from 'react-router';
import MarkerManager from "../../util/marker_manager";

class BenchMap extends React.Component {
  componentDidUpdate(){
    this.MarkerManager.updateMarkers(this.props.benches);
  }


  componentDidMount(){
    const mapDOMNode = document.getElementById("map-container");
    const mapOptions ={
      center: {lat: 37.7758, lng: -122.435},
      zoom: 13
    };
    let that =this
    this.map = new google.maps.Map(mapDOMNode, mapOptions);
    window.map = this.map;
    this.MarkerManager = new MarkerManager(this.map);
    this.MarkerManager.updateMarkers(this.props.benches);
    this.map.addListener('click',this._handleClick.bind(that));
  }

  render(){
    return(
      <div id="map-container" ref="map">
      </div>
    );
  }

  _handleClick(input){

    let coords = {
      lat: input.latLng.lat(),
      lng: input.latLng.lng()
    };

    this.props.router.push({
      pathname: "benches/new",
      query: coords
    });
  }
}

export default withRouter(BenchMap);
