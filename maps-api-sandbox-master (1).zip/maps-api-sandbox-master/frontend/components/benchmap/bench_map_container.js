import React from 'react';
import { connect } from 'react-redux';
import BenchMap from './bench_map';

const mapStateToProps = (state) => {
  return (
    {
      benches: state.BenchesReducer
    }
  );
};

const mapDispatchToProps = (dispatch) => ({

});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BenchMap);
