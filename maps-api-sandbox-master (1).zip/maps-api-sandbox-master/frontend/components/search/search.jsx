import BenchIndexContainer from "../bench_index/bench_index_container";
import BenchMapContainer from "../benchmap/bench_map_container";
import React from 'react';

const Search = () => (
  <div>
    <BenchMapContainer/>
    <BenchIndexContainer/>
  </div>
);

export default Search;
