import React from 'react';
import { connect } from 'react-redux';
import Search from './search';

export default Search;
