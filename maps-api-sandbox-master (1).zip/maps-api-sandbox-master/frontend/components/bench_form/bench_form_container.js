import React from 'react';
import BenchForm from './bench_form';
import { connect } from 'react-redux';
import { createBench } from '../../actions/bench_actions'

const mapStateToProps= (state, ownProps)=> ({
  lat: ownProps.location.query.lat,
  lng: ownProps.location.query.lng
});

const mapDispatchtoProps = (dispatch) => ({
  handleSubmit: (bench) => dispatch(createBench(bench))
});

export default connect(
  mapStateToProps,
  mapDispatchtoProps
)(BenchForm);
