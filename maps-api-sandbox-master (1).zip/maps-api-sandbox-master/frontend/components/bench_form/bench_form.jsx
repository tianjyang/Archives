import React from 'react';
import { withRouter } from 'react-router';

class BenchForm extends React.Component {
  render(){
    return(
      <div>
        <form onSubmit={this.handleSubmit.bind(this)}>
          <input type="text" name="bench_form[description]" placeholder="Description"></input>
          <input type="text" name="bench_form[num_seats]" placeholder="Number of Seats"></input>
          <input type="text" name="bench_form[lat]" placeholder="Latitude" defaultValue={this.props.lat}></input>
          <input type="text" name="bench_form[long]"placeholder="Longitude" defaultValue={this.props.lng}></input>
          <input type="submit"></input>
        </form>
      </div>
    );
  }

  handleSubmit(information){
    information.preventDefault();
    let queryInfo = {
      description: information.currentTarget[0].value,
      seating: information.currentTarget[1].value,
      lat: information.currentTarget[2].value,
      lng: information.currentTarget[3].value,
    };
    this.props.handleSubmit(queryInfo);
    this.props.router.push({pathname: "/"});


  }
}

export default withRouter(BenchForm);
