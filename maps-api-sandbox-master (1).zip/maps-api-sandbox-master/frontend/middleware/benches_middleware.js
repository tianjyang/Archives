import { BenchConstants, receiveBenches} from '../actions/bench_actions';
import { fetchBenches, createBench} from '../util/api_util';

const BenchMiddleware = (store) => (next) => (action) => {
  const success = (data) =>{store.dispatch(receiveBenches(data));};
  switch (action.type) {
    // case BenchConstants.RECEIVE_BENCHES:
    //   console.log("receieve_benches");
    //   return next(action);
    //   // break;
    case BenchConstants.REQUEST_BENCHES:
      fetchBenches(success);
      break;

    case BenchConstants.CREATE_BENCH:
      createBench(action.bench,success);
      break;

    default:
      return next(action);
  }
};

export default BenchMiddleware;
