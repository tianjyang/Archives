class Api::BenchesController < ApplicationController
  def index
    bench = Bench.all
    render json: bench
  end

  def create
    new_bench = Bench.new
    input = bench_params(params)
    puts ("params are #{input}")
    new_bench[:description] = input["description"]
    new_bench[:seating] = input["seating"].to_i
    new_bench[:lat] = input["lat"]
    new_bench[:long] = input["lng"]
    new_bench.save!
    render json: new_bench
  end

  def bench_params(params)
    params.permit(:description,:seating,:lat,:lng)
  end

end
