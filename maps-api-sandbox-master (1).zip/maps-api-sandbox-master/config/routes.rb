Rails.application.routes.draw do
  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
  root 'static_pages#root'

  namespace :api do
    resources :benches, only: [:create, :index], defaults: {format: 'json'}
  end
end
