# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


Bench.create!({description: "wrought iron bench", lat:37.7657476, long: -122.426148})
Bench.create!({description: "sushi rice bench", lat:37.7839354, long: -122.4330962})
Bench.create!({description: "ching chong ling long bench", lat:37.7906415, long: -122.4186105})
Bench.create!({description: "bench for sharp suits", lat:37.7927731, long: -122.4054803})
