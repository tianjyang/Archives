class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :username, null: false
      t.string :pw_dig, null: false
      t.string :ses_toke, null: false
      t.timestamps
    end
    add_index :users, :ses_toke, unique: true
  end
end
