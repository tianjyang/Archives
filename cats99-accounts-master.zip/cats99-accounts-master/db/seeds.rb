# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

josh = User.new(username: "Josh",password:"Password")
josh.save
robert = User.new(username: "Robert",password:"Password")
robert.save


Cat.create!(birth_date: "1987/01/11",color:"orange",name:"Mr. Wiggles",sex:"M",description:"Has a soft tummy",user_id:1)
Cat.create!(birth_date: "1987/01/11",color:"orange",name:"Mrs. Wiggles",sex:"F",description:"Has a hard tummy",user_id:2)
Cat.create!(birth_date: "1987/01/11",color:"black",name:"Dr. Frankenstein",sex:"M",description:"Has no tummy",user_id:2)
