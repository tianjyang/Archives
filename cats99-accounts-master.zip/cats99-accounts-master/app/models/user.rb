class User < ActiveRecord::Base
attr_reader :password
after_initialize :ensure_session_token
validates :password, length: {minimum: 8, allow_nil:true}
validates :username, presence: true
  has_many :cat_rental_requests
  has_many :cats

  def ensure_session_token
    self.ses_toke ||=SecureRandom::urlsafe_base64(32)
  end

  def reset_session_token!
    self.ses_toke = SecureRandom::urlsafe_base64(32)
    self.save!
    self.ses_toke
  end

  def password=(password)
    @password = password
    self.pw_dig = BCrypt::Password.create(password)
  end

  def is_password?(password)
    BCrypt::Password.new(self.pw_dig).is_password?(password)
  end

  def self.find_by_credentials(user_name,password)
    puts "my self is #{self}"
    user = self.find_by(username: user_name)
    if user
      return user if user.is_password?(password)
    else
      return nil
    end
    return nil
  end

end
