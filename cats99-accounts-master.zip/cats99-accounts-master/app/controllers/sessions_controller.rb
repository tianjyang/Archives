class SessionsController < ApplicationController

  before_action :logged_in?, only: [:new]

  def create
    login_user!
  end

  def destroy
    logout if current_user
    session[:session_token] = nil
    redirect_to new_session_url
  end

  private

  def session_params
    params.require(:user).permit(:username, :password)
  end

end
