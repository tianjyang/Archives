require 'test_helper'

class CatRentalRequestsHelperTest < ActionView::TestCase
end
