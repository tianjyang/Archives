require 'json'

class Flash
  def initialize(req)
    @req = req
    @flash = req.cookies["_rails_lite_app_flash"]
    @flashnow
    unless @flash.nil?
      @flash = JSON.parse(@flash)
    else
      @flash = {}
    end
  end

  def []=(key,value)
    @flash[key] = value
  end

  def [](key)
    @flash[key] ||=@now[key]
  end

  def store_flash(res)
    res.set_cookie("_rails_lite_app_flash",@flash.to_json)
  end

  def now
    @now ||= Flash.new(@req)
  end

end
