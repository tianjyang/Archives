require 'active_support'
require 'active_support/core_ext'
require 'erb'
require_relative './session'

class ControllerBase
  attr_reader :req, :res, :params

  @@protect = false

  def form_authenticity_token
    @req.cookies['authenticity_token'] ||= SecureRandom.urlsafe_base64(8)
    @res.set_cookie('authenticity_token',@req.cookies['authenticity_token'])
    @req.cookies['authenticity_token']
  end

  def self.protect_from_forgery
    @@protect = true
  end

  def check_authenticity_token
    puts "params authenticity token: #{params["authenticity_token"]}"
    puts "cookie authenticity token: #{@req.cookies['authenticity_token']}"
    unless params["authenticity_token"] == @req.cookies['authenticity_token']
      raise "Invalid authenticity token"
      @already_built_response = true
    end

    if params["authenticity_token"].nil? || @req.cookies['authenticity_token'].nil?
      raise "Invalid authenticity token"
      @already_built_response = true
    end

  end



  # Setup the controller
  def initialize(req, res, params= {})
    @req = req
    @res = res
    @already_built_response = false
    @params = params
  end

  # Helper method to alias @already_built_response
  def already_built_response?
    @already_built_response
  end

  # Set the response status code and header
  def redirect_to(url)
    raise "content has been rendered!" if already_built_response?
    @already_built_response = true
    @res.status = 302
    @res['Location'] = url
    session.store_session(@res)
  end

  # Populate the response with content.
  # Set the response's content type to the given type.
  # Raise an error if the developer tries to double render.
  def render_content(content, content_type)
    raise "content has been rendered!" if already_built_response?
    @already_built_response = true
    @res.body = [content]
    @res['Content-Type'] = content_type
    session.store_session(@res)
  end

  # use ERB and binding to evaluate templates
  # pass the rendered html to render_content
  def render(template_name)
    raise "content has been rendered!" if already_built_response?
    @already_built_response = true
    controller_name = self.class.to_s.underscore
    @res.body = [ERB.new(File.read("views/#{controller_name}/#{template_name}.html.erb")).result(binding)]
    @res['Content-Type'] = "text/html"
    session.store_session(@res)

  end

  # method exposing a `Session` object
  def session
    @session ||= Session.new(@req)
  end

  # use this with the router to call action_name (:index, :show, :create...)
  def invoke_action(name)
    if @@protect && @req.request_method != "GET"
      check_authenticity_token
    end
    send(name) unless already_built_response?
    @already_built_response = true
  end
end
