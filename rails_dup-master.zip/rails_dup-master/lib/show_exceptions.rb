require 'erb'

class ShowExceptions
  attr_reader :app
  def initialize(app)
    @app = app
  end

  def call(env)
    begin
      app.call(env)
    rescue => error
      puts "standard error #{error.inspect}"
      output = ['500',{'Content-type' => 'text/html'}]
      file = File.read('lib/templates/rescue.html.erb')
      # body = [ERB.new(file).result(binding)]
      body = [error.to_s]
      output << body
      env['status'] = 500
      output
    end
  end

  private

  def render_exception(e)
  end

end
