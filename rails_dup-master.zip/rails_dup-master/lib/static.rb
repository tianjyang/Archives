class Static
  def initialize(app)
    @app = app
  end

  def call(env)
    begin
      # puts env
      # puts env.class
      # puts "curent workig directory = #{Dir.pwd}"
      # puts "env path info #{env['PATH_INFO']}"
      filename = env['PATH_INFO']
      filename = filename.slice(1..-1)
      # puts filename
      file = File.read(filename)
      ['200',{'Content-Type' => 'text/html'},file]
    rescue => errors
      ['404',{'Content-Type' => 'text/html'},["FILE NOT FOUND"]]
    end
  end
end
