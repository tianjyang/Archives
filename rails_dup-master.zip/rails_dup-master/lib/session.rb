require 'json'

class Session
  # find the cookie for this app
  # deserialize the cookie into a hash
  def initialize(req)
    puts "incoming cookies are #{req.cookies}"
    @cookies = req.cookies["_rails_lite_app"]
    unless @cookies.nil?
      @cookies = JSON.parse(@cookies)
    else
      @cookies = {}
    end
  end

  def [](key)
    @cookies[key]
  end

  def []=(key, val)
    @cookies[key] = val
  end

  # serialize the hash into json and save in a cookie
  # add to the responses cookies
  def store_session(res)
    # res["_rails_lite_app"]=@cookies.to_json
    # res["cookie"]= {"_rails_lite_app" => @cookies}.to_json
    res.set_cookie("_rails_lite_app",@cookies.to_json)


  end
end
