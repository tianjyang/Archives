require 'byebug'

#write a recursive method for implementing a binary search on an array.
def binarysearch(array,val)
end


#write a method which returns an array of the first "num" values of the fibonacci sequence
def fibonacci(num)
end