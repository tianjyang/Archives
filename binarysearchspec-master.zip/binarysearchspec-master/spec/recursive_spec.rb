require 'rspec'
require 'recursive'

describe 'binarysearch' do

  it 'correctly finds the index for the following test case' do
    expect(binarysearch([1,2,3],1)).to eq(0)
  end
  
   it 'correctly finds the index for the following test case' do
    expect(binarysearch([2, 3, 4, 5], 3)).to eq(1)
  end
  
  it 'correctly finds the index for the following test case'do
    expect(binarysearch([2, 4, 6, 8, 10], 6)).to eq(2)
  end
  
  it 'correctly finds the index for the following test case' do
    expect(binarysearch([1, 3, 4, 5, 9], 5)).to eq(3)
  end
  
  it 'correctly finds the index for the following test case' do
    expect(binarysearch([1, 2, 3, 4, 5, 6], 6)).to eq(5)
  end
  
  it 'returns nil if value is not found on the left' do
    expect(binarysearch([1, 2, 3, 4, 5, 6], 0)).to be_nil
  end
  
    it 'returns nil if value is not found on the right' do
    expect(binarysearch([1, 2, 3, 4, 5, 6], 7)).to be_nil
  end
  
  
    it "calls itself recursively" do
    expect(self).to receive(:binarysearch).at_least(:twice).and_call_original
    binarysearch([1,2,3,4,5,6,7],6)
  end

end

describe 'fibonacci' do 
  
  it 'it correctly returns the first 2 values of the fibonacci sequence' do
    expect(fibonacci(2)).to eq([1,1])
  end
  
    it 'it correctly returns the first 10 values of the fibonacci sequence' do
    expect(fibonacci(10)).to eq([1, 1, 2, 3, 5, 8, 13, 21, 34, 55])
  end
  
  it "calls itself recursively" do
    expect(self).to receive(:fibonacci).at_least(:twice).and_call_original
    fibonacci(10)
  end
end