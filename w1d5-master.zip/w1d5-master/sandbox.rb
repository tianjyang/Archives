puts [].empty?
