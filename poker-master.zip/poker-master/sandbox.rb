a=[1,23,4,5]
a.pop(2)
print a
