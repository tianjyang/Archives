class Hand
  attr_reader :books, :cards

  def initialize(cards = [])
    @cards = cards
    @books = 0
  end

  def include?(value)
    @cards.each do |card|
      return true if card.value == value
    end
    false
  end

  def empty?
    count == 0
  end

  def count
    @cards.count
  end

  def give_up(value)
    if include?(value)
      cards_to_pass = []
      @cards.each do |card|
        if card.value == value
          cards_to_pass << card
        end
      end
      @cards -= cards_to_pass
      cards_to_pass
    else
      cards_to_pass = []
    end
  end

  def receive(new_cards)
    @cards += new_cards
  end

  # This method isn't tested, but we strongly recommend you implement it as a
  # helper method. It should return a hash mapping values to the number of
  # matching cards in the hand (e.g., { king: 2, deuce: 3 })
  def count_sets
    print "ount sets caled"
    @card_count = Hash.new(0)
    @cards.each do |card|
      puts "card. valeu is #{card.value}"
      @card_count[card.value] += 1
    end
  end

  def play_books
    count_sets
    books_to_remove = nil
    @card_count.each do |value,count|
      books_to_remove = value if count == 4
      @books += 1 if count == 4
    end

    new_cards = []
    @cards.each do |card|
      new_cards << card unless card.value == books_to_remove
    end
    @cards = new_cards

  end
end
