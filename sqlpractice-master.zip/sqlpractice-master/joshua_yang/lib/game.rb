class Game
  attr_reader :deck, :players

  def initialize(players, deck = Deck.new, deal = true)
    @deck = deck
    @players = players
    deal_players_in if deal
  end

  def deal_players_in
    # DO NOT MODIFY
    players.each { |player| player.take(deck.deal(7)) }
  end

  # switch the current player
  def next_player!
    next_player = @players.shift
    @players << next_player
  end

  def current_player
    @players.first
  end

  # returns all non-current players
  def other_players
    @players[1..-1]
  end

  def play
    until game_over?
      play_turn
    end

    puts "#{winner.name} wins!"
  end

  # If the current player receives cards, they take another turn (that is, this
  # method returns without passing the turn to the next player). Otherwise, the
  # current player has to "go fish" and the turn passes to the next player.
  def play_turn
    request = current_player.make_request
    value,other_player = request[0],request[1]
    if other_player.has_value?(value)
      current_player.take(other_player.give_up(value))
    else
      current_player.go_fish(@deck)
      next_player!
    end

  end

  def game_over?
    return false if @players.any?{|player| player.in_play?}
    return true if @deck.empty?

  end

  def winner
    winner = nil
    best = 0

    @players.each do |player|
      if player.books > best
        winner = player
      end
    end
    winner
  end
end
