def anagrams(str1, str2)
  anagram = first_anagram(str1)
  anagram.include?(str2)
end


def first_anagram(str1)
  str1.chars.permutation.to_a.map{|x| x.join}
end

def second_anagram?(str1, str2)
  x = str1.chars
  y = str2.chars
  i = 0
  while i < x.length do
    j = 0
    while j < x.length do
      if x[i] == y[j]
        x.delete_at(i)
        y.delete_at(j)
        i -= 1
        j -= 1
      end
      j += 1
    end
    i +=1
  end
x.empty? && y.empty?
end



def third_anagram?(str1,str2)
  sorted_1 = str1.sort
  sorted_2 = str2.sort
  sorted_1 == sorted_2
end

def fourth_anagram(str1,str2)
  hash1 = Hash.new(0)
  hash2 = Hash.new(0)
  str1.split("").each{|x| hash1[x] += 1}
  str2.split("").each{|x| hash2[x] += 1}
  hash1 == hash2
end
