def two_sum_bad(arr,val)
  for x in 0...arr.length do
    for y in (x+1)...arr.length do
      return true if arr[x] + arr[y] == val
    end
  end
  false
end

def two_sum_okay(arr,val)
  output = false
  sorted = arr.sort
  arr.each do |x|
    return true if sorted.bsearch_index{|y| y == val-x}.class == Fixnum
    sorted.shift
  end
  false
end

def two_sum_best(arr,val)
  hash = Hash.new(0)
  arr.each{|x| hash[x] += 1}
  output = 0
  arr.each do |x|
    output += hash[val-x]
  end
  return output > 1
end

arr = [0, 1, 5, 7]



class MyQueue
  def initialize
    @store = []
  end

  def enqueue(n)
    @store.unshift(n)
  end

  def dequeue
    @store.pop
  end

  def peek
    [@store.first, @store.last]
  end

  def size
    @store.count
  end

  def empty?
    @store.empty?
  end

end

class MyStack
  attr_accessor :store
  def initialize
    @store = []
  end

  def pop
    @store.pop
  end

  def push(n)
    @store << n
  end

  def peek
    [@store.first, @store.last]
  end

  def size
    @store.size
  end


  def empty
    @store.empty?
  end
end

StackQueue
