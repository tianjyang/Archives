def my_min_phase1(array)
  min = array.first
  array.each do |x|
    array.each do |y|
      min = x if x < y && x != y
    end
  end
  min
end

def my_min_phase2(array)
  min = array.first
  array.each do |x|
    min = x if x <= min
  end
  min
end


def sub_sum_phase1(array)
  sub_arrays = []
  for x in 0...array.length
    for y in x...array.length
      sub_array = array[x..y]
      sub_arrays << sub_array
    end
  end
  largest_sum = array.first
  sub_arrays.each do |x|
    sub_sum = sum(x)
    largest_sum = sub_sum if sub_sum > largest_sum
  end
  largest_sum
end

def sum(array)
  sum = 0
  array.each do |x|
    sum += x
  end
  sum
end

def sub_sum_phase2(array)
  max = array.first
  sub_sum = 0
  array.each do |x|
    if x > 0
      sub_sum += x
    else
      if x + sub_sum < 0
        max = sub_sum if sub_sum > max
        sub_sum = 0
      else
        sub_sum += x
      end
    end
  end
  max = sub_sum if sub_sum > max
  max
end

list = [2, 3, -6, 7, -6, 7]
puts sub_sum_phase2(list)
