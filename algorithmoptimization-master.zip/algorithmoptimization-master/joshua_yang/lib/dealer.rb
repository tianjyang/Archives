require_relative 'player'

class Dealer < Player
  attr_reader :bets

  def initialize
    super("dealer", 0)
    @points = 0

    @bets = {}
  end

  def place_bet(dealer, amt)
    raise "Dealer doesn't bet"
  end

  def play_hand(deck)

    while @hand.points < 17
      @hand.hit(deck)
      if @hand.points > 21
        @hand.busted?
      end
    end

  end

  def take_bet(player, amt)
    @bets[player] = amt
  end

  def pay_bets
    players = @bets.keys
    players.each do |x|
      if x.hand.beats?(@hand)
        x.pay_winngs(2*@bets[x])
      end
    end
  end
end
