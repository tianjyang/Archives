class Hand
  # This is called a *factory method*; it's a *class method* that
  # takes the a `Deck` and creates and returns a `Hand`
  # object. This is in contrast to the `#initialize` method that
  # expects an `Array` of cards to hold.
  def self.deal_from(deck)
    cards = deck.take(2)
    self.new(cards)



  end

  attr_accessor :cards, :points

  def initialize(cards)
    @cards = cards
    find_value_of_cards
  end

  def find_value_of_cards
    num_aces =0
    @points = 0
    @cards.each do |x|
      unless x.value == :ace
      @points += x.blackjack_value
      else
        num_aces += 1
      end
    end
    possible_aces = [1,11]
    puts "num_aces = #{num_aces}"
    (num_aces-1).times do
      first_adder = [0]+possible_aces
      second_adder = possible_aces + [0]
      new_arr = first_adder.dup
      for x in 0...first_adder.length do
        new_arr[x] = first_adder[x]+second_adder[x]
      end
      possible_aces = new_arr
    end
    possible_aces = [] if num_aces == 0
    possible_aces.each do |x|
      print "accessing #{x} and #{@points}"
      if @points + x <= 21 && (@points + x) > @points
        @points += x
      end
    end




    @points
  end

  def points
    @points
  end

  def busted?
    @points > 21
  end

  def hit(deck)
    raise "already busted" if busted?
    cards = deck.take(1)
    @cards.concat(cards)
  end

  def beats?(other_hand)
    my_value = self.find_value_of_cards
    his_value = self.find_value_of_cards
    my_value > his_value

  end

  def return_cards(deck)
  end

  def to_s
    @cards.join(",") + " (#{points})"
  end
end
