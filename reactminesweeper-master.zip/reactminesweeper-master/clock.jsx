import React from 'react';
import ReactDOM from 'react-dom';

class Clock extends React.Component {
  constructor(props) {
    super(props);
    this.state = {time: new Date()};
    this.intervalId = null;
  }

  componentDidMount() {
    
    this.intervalId = setInterval( () => {
      let time = this.state.time;
      time.setSeconds(this.state.time.getSeconds() + 1);
      this.setState({time: time});
    },1000);
  }

  componentWillUnmount() {
    this.intervalId = 0;
  }

  render () {
    return <h1>{this.state.time.toString()}</h1>;
  }
}

export default Clock;
