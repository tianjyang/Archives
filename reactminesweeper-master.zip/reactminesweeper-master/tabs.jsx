import React from 'react';
import ReactDOM from 'react-dom';


class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {selected: 0};
  }

  updateSelected(i) {
    this.setState({selected: i});
  }
  render () {
    return (<div>
      <ul>
        {this.props.tabInfo.map((element,i) => {
          return <li key={element.title} onClick={this.updateSelected.bind(this, i)}>
            <h1>{element.title}</h1></li>;
        })}
        {this.props.tabInfo[this.state.selected].content}
      </ul>
    </div>);
  }
}

export default Tabs;
