import React from 'react';
import ReactDOM from 'react-dom';

class Weather extends React.Component {
  constructor(props) {
    super(props);
    this.state = {weather: {main: {temp: "temp holder"}, weather:[{description:"weather holder"}]}};
  }

  componentDidMount() {
    let that = this;
    navigator.geolocation.getCurrentPosition( ({coords: {latitude, longitude}}) => {
      console.log("location finished");
      let request = new XMLHttpRequest();
      let url = `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&APPID=645c5d39c7603f17e23fcaffcea1a3c1`;
      request.open('GET', url, true);
      request.onload = function() {
        if (request.status >= 200 && request.status < 400) {
          console.log("request success");
          let resp = JSON.parse(request.responseText);
          that.setState({weather: resp});
        } else {
          console.log("API request failed");
        }
      };
      request.send();
    });
  }

  render() {
    console.log("weather is");
    console.log(this.state.weather.weather[0].description);
    let weatherString = this.state.weather.weather[0].description;
    let tempString= this.state.weather.main.temp;
    return (
      <div>
      <h1>Weather</h1>
        <h4> {weatherString} {tempString}
      </h4>
      </div>
    );
  }
}

export default Weather;
