import Board from './board';
import * as Minesweeper from './minesweeper';
import React from 'react';
import ReactDOM from 'react-dom';

class Game extends React.Component {
  constructor() {
    super();
    this.state = {board: new Minesweeper.Board(10,10)};
    this.updateGame = this.updateGame.bind(this);
  }

  updateGame(tile,flagged) {
    let that = this;
    if (flagged) {
      tile.toggleFlag();
    } else {
      tile.explore();
    }
    this.setState({board: that.state.board});
    let gameMessage = undefined;
    if (this.state.board.won()) {
      gameMessage = "you won";
    } else if (this.state.board.lost()) {
      gameMessage = "You lost";
    }

    if (gameMessage!== undefined) {
      let modal = document.getElementById('myModal');
      let modalContent = document.querySelectorAll('.modal-content');
      modalContent[0].innerHTML = `${gameMessage} <input type="button" id="replay" value="Replay"></input>`;
      let restart = document.getElementById("replay");
      restart.addEventListener("click",() => {
        modal.style.display="none"
        this.setState({board: new Minesweeper.Board(10,10)});
      });
      modal.style.display = "block";



    }


  }

  render() {
    return <div><Board board={this.state.board}
      updateGame={this.updateGame}/></div>;
  }

}

export default Game;
