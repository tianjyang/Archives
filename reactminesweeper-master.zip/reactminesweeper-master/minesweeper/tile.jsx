import * as Minesweeper from './minesweeper';
import React from 'react';
import ReactDOM from 'react-dom';

class Tile extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(e) {
    let flagged = false;
    if (e.altKey) {

      flagged = true;
    }
    this.props.updateGame(this.props.tile,flagged);
  }

  render() {
    let tile = this.props.tile;
    let status = "";
    let tileClass = "tile";
    if (tile.flagged) {
      status = "⚑";
      tileClass = "tile flagged";
    } else if (tile.explored) {
      status = tile.adjacentBombCount();
      if (status === 0) status = "";
      tileClass = "tile explored ";
      if (tile.bombed) {
        status = "💣";
        tileClass = "tile bombed";
      }
    }
    return <div onClick={this.handleClick} className={tileClass}>{status}</div>;
  }
}

export default Tile;
