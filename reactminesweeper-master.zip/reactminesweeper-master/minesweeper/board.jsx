import * as Minesweeper from './minesweeper';
import Tile from './tile';
import React from 'react';
import ReactDOM from 'react-dom';

class Board extends React.Component{
  constructor(props) {
    super(props);
  }

  render(){
    let grid = this.props.board.grid;
    return (
      <div>
      {grid.map((el,idx1)=>{
        return(<div key={idx1.toString()} className="row">
        {el.map((tile,idx2)=>{
          return (
            <Tile
              tile={this.props.board.grid[idx1][idx2]}
              updateGame={this.props.updateGame}
              key={((idx1*10)+idx2).toString()}/>
          );
        })}
        </div>);
      })}
      </div>
    );
  }
}

export default Board;
