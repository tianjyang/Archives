import React from 'react';
import ReactDOM from 'react-dom';

class AutoComplete extends React.Component {
  constructor(prop) {
    super(prop);
    this.state = {stateNames: this.props.names};
  }

  updateNames(e) {
    let currentTarget = e.currentTarget;
    let partial = currentTarget.value;
    let newNames = this.props.names.filter( (name) => {
      return partial.toLowerCase()  === name.slice(0,partial.length).toLowerCase();
    });
    this.setState({stateNames: newNames});
  }

  clickName(name){
    document.getElementById('nameInput').value = name;
    this.setState({stateNames: [name]});
  }

  render() {
    return (
      <div>
        <input type="text" id="nameInput" onChange={this.updateNames.bind(this)}/>
        <ul>
          {this.state.stateNames.map( (name, idx) => {
            return <li key={idx} onClick={this.clickName.bind(this,name)}>{name}</li>;
          })}
        </ul>
      </div>
    );
  }
}

export default AutoComplete;
