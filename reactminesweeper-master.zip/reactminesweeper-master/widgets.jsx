import React from 'react';
import ReactDOM from 'react-dom';
import Tabs from './tabs';
import Clock from './clock';
import Weather from './weather';
import AutoComplete from './autocomplete';


document.addEventListener("DOMContentLoaded",()=>{
  // start something
  let root = document.getElementById("root");
  ReactDOM.render(<Widgets/>,root);
});

class Widgets extends React.Component {
  constructor () {
    super();

  }

  render() {
    let objectArray = [ {title: "one", content:"I am the first"},
    {title: "two", content:"I am the second"},
    {title: "three", content:"I am the third"}];

    let nameArray = ["Abba",
      "Barney",
      "Barbara",
      "Jeff",
      "Jenny",
      "Sarah",
      "Sally",
      "Xander"];

    return(
      <div>
        <Tabs tabInfo={objectArray}/>
        <Clock/>
        <Weather/>
        <AutoComplete names={nameArray}/>
      </div>
    );
  }
}
